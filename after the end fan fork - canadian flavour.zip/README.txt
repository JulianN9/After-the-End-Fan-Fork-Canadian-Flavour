NEED ORIGINAL AFTER THE END: 
https://forum.paradoxplaza.com/forum/index.php?threads/after-the-end-a-post-apocalyptic-america-mod.831384/

Installation:
Delete any old versions of this mod you have. 
Drag and place "After the End - Canadian Flavour" and its .mod file into mod folder 
at: documents/Paradox Interactive/Crusader Kings II/mod. 

DO NOT MERGE WITH BASE AFTER THE END.

Features:
Full featured confederationalism - coronations, crusades, and saints.
Confederationalism is now a triarchy
New Confederated heresy - the United Church
Canadian renaissance - revitalise the post event candian culture, if the quebecois will let you.
New unification bloodllines
Reformable provinces
New empire for BC and nouvelle France
4 new old world cultist religions - Dominionism,Rinkite,Lyonism, and the Church of the Three mothers
New warrior lodge for new religions

Credits:
Scripted by Conquest
Written by Pizzamaster and Conquest
Images by Conquest
This mod is entirely based on and supported by the wonderful work done by the ateff team. Please show them all the support you can.